# สร้าง Series
import pandas as pd
s = pd.Series([10, 20, 30])
print(s)

# สร้าง DataFrame
import pandas as pd
df = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Age': [25, 30, 22]
})
print(df)

