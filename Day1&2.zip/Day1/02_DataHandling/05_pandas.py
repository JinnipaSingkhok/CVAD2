import pandas as pd
data = {'Name': ['Ann', 'Ben'], 'Score': [90, 85]}
df = pd.DataFrame(data)
print(df)