#standard form

def add(x,y):
    return x+y
print(add(x=1, y=2))
print(add(1,2))

#Lambda form
#Syntax : lambda arguments: expression

add = lambda x,y:x+y
print(add(1,2))